#ifndef PARAMETERS_MHD_H
#define PARAMETERS_MHD_H

#define A 0.0
#define B 1.0

#define Nel 64
#define I (Nel+1)
#define J I

#define h (((double)B - (double)A)/(double)Nel)

#define Pr (double) 1.0
#define Ra (double) 1.e3
#define Ha (double) 10.0

#define alpha_psi (double) 1.0
#define alpha_w (double) 1.0
#define alpha_T (double) 1.0

#define which_h 1

#endif