#ifndef MYTRIDIAG_H
#define MYTRIDIAG_H

#include <stdio.h>
#include <stdlib.h>

double* myTridiag(double b[], double a[], double c[], double f[], const size_t n);

#endif